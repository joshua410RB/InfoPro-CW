#include <sys/alt_stdio.h>
#include <stdio.h>
#include "altera_avalon_pio_regs.h"
#include "system.h"
#define CHARLIM 256	//Maximum character length of what the user places in memory.  Increase to allow longer sequences
#define CLOCKINIT 400000	//Initial speed of the display.  This is a good starting point

void initializeDisplay();
void updateText();
char getTxt(char curr);
int getActualText();
void clearActualText();
int updateLocation(int loc, int len);
void updatePBState(int button_datain);
int getBin(char letter);
void print(int let5, int let4, int let3, int let2, int let1, int let0);
void print_letters(char let5, char let4, char let3, char let2, char let1, char let0);


char prevLetter;	//The last letter the user entered, used for determining whether or not the display has been updated
char enteredText[CHARLIM]; //The text that the user enters
char text[2*CHARLIM];//The text that has been adjusted for the allowed letters
int pause, length, re_enter, disp_off, flag;
int timer = CLOCKINIT;  //Standard speed for movement
int chicken = 1;

int main(){
  int location = 0; //Keeps track of where we are in the display, used for scrolling the text

  /* Event loop never exits.*/
  while (1){
	  //Update the display; delay so the letters stay on the screen (hence the loop)
	  if(chicken == 1){
		  location = updateLocation(location, 10);  //The amount we should shift each letter by based on the user input
		  			  char first_name[15] = {'A','N','T','H','O','N','Y','\0'};
		  for(int i = 0; i< timer; i++){

			  print_letters(first_name[(location % 10)], first_name[(location + 1) % 10], first_name[(location + 2) % 10], first_name[(location + 3) % 10], first_name[(location + 4) % 10], first_name[(location + 5) % 10]);
		   }
//		  location = updateLocation(location, 10);  //The amount we should shift each letter by based on the user input
//		  char first_name[15] = {'A','N','T','H','O','N','Y','\0'};
//		  print_letters(first_name[(location % 10)], first_name[(location + 1) % 10], first_name[(location + 2) % 10], first_name[(location + 3) % 10], first_name[(location + 4) % 10], first_name[(location + 5) % 10]);
		  } else {
//		  for(int i = 0; i< timer; i++){ }
//		  location = updateLocation(location, 10);  //The amount we should shift each letter by based on the user input
//		  char first_name[15] = {'B','E','T','H','O','L','D','\0'};
//		  print_letters(first_name[(location % 10)], first_name[(location + 1) % 10], first_name[(location + 2) % 10], first_name[(location + 3) % 10], first_name[(location + 4) % 10], first_name[(location + 5) % 10]);
	  }
  }
//  return 0;
}



//Updates the text from the console once the program is running
void updateText(){
	if (re_enter){
		  alt_putstr("Put your new text into the console and press ENTER\n");
		  prevLetter = '!';
		  prevLetter = getTxt(prevLetter);
		  length = getActualText();		//Adjust for special characters such as 'W' or 'M'
		  if(length > 0)
			  text[length-1] = '\0';		//Get rid of any extra stuff at the end
		  alt_putstr("Got it!  If you want to change the text, press KEY1 \n");
		  re_enter = 0;	//We don't want to retrigger the entering process until the user does
	}
	return;
}

//Gets the text the user placed on the console
char getTxt(char curr){
	if(curr == '\n')
		return curr;
	int idx = 0;	//Keep track of what we are adding
	char newCurr = curr;
	//Keep adding characters until we get to the end of the line
	while (newCurr != '\n'){
		enteredText[idx] = newCurr;	//Add the next letter to the entered text register
		idx ++;
		newCurr = alt_getchar();	//Get the next character
	}
	length = idx;
	return newCurr;
}

//Takes the user's input and only uses the allowed letters.  Returns the length of the string entered
int getActualText(){
	int idx = 0;	//We need two indicies because the entered and actual text sequences need not be aligned
	char currentLetter; //Keeps track of the character we are wanting to add
	//Go through each letter in the entered text
	for (int i = 0; i <= length; i++){
		currentLetter = enteredText[i];
		if (currentLetter > 96){
			//Gets only the uppercase letter
			currentLetter -= 32;
		}
		switch(currentLetter){
		case 'M':
			//We build the letter "M" from two "n's," so we need to change the index twice in the actual text
			text[idx] = 'N';
			text[idx + 1] = 'N';
			idx += 2;
			break;
		case 'W':
			//We build the letter "W" from two "v's," so we need to change the index twice in the actual text
			text[idx] = 'V';
			text[idx + 1] = 'V';
			idx += 2;
			break;
		default:
			//Copy the new letter into the actual text
			text[idx] = currentLetter;
			idx++;
		}
	}
	return idx;
}

//This function clears the text on the display:
void clearActualText(){
	for(int i = 0; i <= length; i++){
		text[i] = '\0';
	}
	return;
}

//This function returns a new Location based on the previous one.
int updateLocation(int loc, int len){
	  //Move the display if we are unpaused
		  if (pause == 0){
				loc++;   //Move the display forwards if the backwards button is NOT toggled (KEY2)
		  }
		  if (loc >= len){ //If we have reached the end of the string, reset the locator back to the beginning
			  return loc % len;
		  }
		  else if (loc < 0){ //If we have reached the end of the string backwards, we need to jump back the other way
			  return loc + len;
		  }
		  return loc;
}

//Gets the binary representation of the character
int getBin(char letter){
	/*Based on the character entered, we convert to binary so the 7-segment knows which lights to turn on.
	The 7-segment has inverted logic so a 0 means the light is on and a 1 means the light is off.
	The rightmost bit starts the index at HEX#[0], and the leftmost bit is HEX#[6], the pattern
	for the 7-segment is shown in the DE0_C5 User Manual*/
	switch(letter){
	case '0':
		return 0b1000000;
	case '1':
		return 0b1111001;
	case '2':
		return 0b0100100;
	case '3':
		return 0b0110000;
	case '4':
		return 0b0011001;
	case '5':
	case '6':
		return 0b0000010;
	case '7':
		return 0b1111000;
	case '8':
		return 0b0000000;
	case '9':
		return 0b0010000;
	case 'A':
		return 0b0001000;
	case 'B'://Lowercase
		return 0b0000011;
	case 'C':
		return 0b1000110;
	case 'D'://Lowercase
		return 0b0100001;
	case 'E':
		return 0b0000110;
	case 'F':
		return 0b0001110;
	case 'G':
		return 0b0010000;
	case 'H':
		return 0b0001001;
	case 'I':
		return 0b1111001;
	case 'J':
		return 0b1110001;
	case 'K':
		return 0b0001010;
	case 'L':
		return 0b1000111;
	case 'N':
		return 0b0101011;
	case 'O':
		return 0b1000000;
	case 'P':
		return 0b0001100;
	case 'Q':
		return 0b0011000;
	case 'R'://Lowercase
		return 0b0101111;
	case 'S':
		return 0b0010010;
	case 'T':
		return 0b0000111;
	case 'U':
		return 0b1000001;
	case 'V':
		return 0b1100011;
	case 'X':
		return 0b0011011;
	case 'Y':
		return 0b0010001;
	case 'Z':
		return 0b0100100;
	default:
		return 0b1111111;
	}
}

//Prints each of the letters out to the screen
void print(int let5, int let4, int let3, int let2, int let1, int let0){
	//Takes the binary value for each letter and places it on each of the six 7-segment displays
	IOWR_ALTERA_AVALON_PIO_DATA(HEX5_BASE, let5);
	IOWR_ALTERA_AVALON_PIO_DATA(HEX4_BASE, let4);
	IOWR_ALTERA_AVALON_PIO_DATA(HEX3_BASE, let3);
	IOWR_ALTERA_AVALON_PIO_DATA(HEX2_BASE, let2);
	IOWR_ALTERA_AVALON_PIO_DATA(HEX1_BASE, let1);
	IOWR_ALTERA_AVALON_PIO_DATA(HEX0_BASE, let0);
	return;
}
//Prints each of the letters out to the screen; takes into account the dancing letters
void print_letters(char let5, char let4, char let3, char let2, char let1, char let0){
	//If the display is "muted," don't show anything
	if (disp_off){
		print(getBin('!'), getBin('!'), getBin('!'), getBin('!'), getBin('!'), getBin('!'));
		return;
	}
	else {
        IOWR_ALTERA_AVALON_PIO_DATA(HEX5_BASE, getBin(let5));
		IOWR_ALTERA_AVALON_PIO_DATA(HEX4_BASE, getBin(let4));
		IOWR_ALTERA_AVALON_PIO_DATA(HEX3_BASE, getBin(let3));
		IOWR_ALTERA_AVALON_PIO_DATA(HEX2_BASE, getBin(let2));
		IOWR_ALTERA_AVALON_PIO_DATA(HEX1_BASE, getBin(let1));
		IOWR_ALTERA_AVALON_PIO_DATA(HEX0_BASE, getBin(let0));
		return;
    }
}

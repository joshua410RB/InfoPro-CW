using programmer, blast DE10_LITE_Golden_Top.sof (found in Golden_Top folder) onto FPGA
go into eclipse, use hello world small project template using the accel_7seg.sopcinfo
right click on your name_bsp folder, click on Nios II > BSP Editor and uncheck the small c library box
build project and run as nios 2 hardware

What's in this c code:

Normal mode: makes use of no filter. toggled by 'n'
Slow mode: makes use of moving avg filter with 5 coeffs, 0x1999 each. this mode is when u kena bombed. toggled by 's'
Stop mode: makes use of moving avg filter with 5 coeffs, 0x0000. this mode is when u run into obstacles? toggled by 'x'

all 3 modes print out to terminal:
x_raw: something, x_filtered = something
y_raw: something, y_filtered = something

7-seg display also shows which mode player is in.

whenever player picks up bomb, toggle 'b' to increment bomb_count.
7-seg display will show bomb and bomb count, terminal will show 
bomb_count: something

To throw bomb, press key1 (lower button).
7-seg dislpay will show "throw". terminal will show
Bomb has been thrown!
bomb_count: something

Issues:
I have this issue whereby when I'm printing to terminal the x_raw: smth, x_filtered = smth, it doesn't allow me to type in any letters
can someone else just download and unzip this folder to check if they have the same issue?